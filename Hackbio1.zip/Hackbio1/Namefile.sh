#! /bin/sh
#My Code for names

echo "What is your first name? "
read firstname
echo "Hello $firstname"
echo "What is your last name? "
read lastname
echo "Hello $firstname $lastname "
#Version were the names are printed on different lines
echo $firstname
echo $lastname